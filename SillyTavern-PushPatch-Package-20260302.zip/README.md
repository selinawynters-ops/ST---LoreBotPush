﻿# SillyTavern Push-Patch Package

This package contains the exact files modified to support:
- Push buttons in the World Info UI
- Push/Bulk Push backend routes
- Locked/hidden lorebook access rules (admin + original creator only)
- Pushed character advanced-definition lock rules

## Included Files (and where to place them)
Copy each file into the same relative path inside your SillyTavern install root.

- `public/index.html` -> `<SillyTavernRoot>/public/index.html`
- `public/style.css` -> `<SillyTavernRoot>/public/style.css`
- `public/scripts/world-info.js` -> `<SillyTavernRoot>/public/scripts/world-info.js`
- `src/endpoints/worldinfo.js` -> `<SillyTavernRoot>/src/endpoints/worldinfo.js`
- `src/endpoints/characters.js` -> `<SillyTavernRoot>/src/endpoints/characters.js`

## What Each File Does

### 1) `public/index.html`
- Adds the toolbar buttons in World Info popup:
  - `#world_popup_share` (single push)
  - `#world_bulk_push` (admin bulk push)
- Without this, push actions are not visible in UI.

### 2) `public/style.css`
- Adds icon styling for push buttons.
- Keeps `@charset "UTF-8"` at top for valid CSS parsing.

### 3) `public/scripts/world-info.js`
- Adds frontend logic for:
  - single push popup (`/api/worldinfo/push`)
  - bulk push popup (`/api/worldinfo/bulk-push`)
  - linked character discovery (`/api/worldinfo/find-characters`)
  - admin-target discovery (`/api/worldinfo/admin-handles`)
- Shows/hides buttons appropriately (bulk for admins).

### 4) `src/endpoints/worldinfo.js`
- Adds backend routes and push manifest support:
  - `/push`, `/bulk-push`, `/find-characters`, `/admin-handles`, `/push-notifications`
- Enforces lock/hidden behavior:
  - hidden pushed lorebooks only accessible by admin or original creator
  - non-admin/non-creator blocked from get/edit/delete for hidden+locked pushed books
- Preserves `dd-*` creator ownership when admin re-pushes user-origin lorebooks.

### 5) `src/endpoints/characters.js`
- Adds pushed-character protections for advanced definition fields.
- Prevents non-admin/non-creator from changing protected advanced fields.
- Preserves push metadata and sync behavior when applicable.

## Rule Behavior Implemented

### User -> Admin -> Everyone flow
1. User pushes lorebook to admin: named `dd-{creatorHandle}-{label}`.
2. Admin re-pushes that same `dd-*` lorebook:
   - name is preserved (`dd-*` stays `dd-*`)
   - original creator metadata is preserved
   - hidden/locked metadata remains enabled
3. Visibility/editing:
   - Admin: always allowed
   - Original creator: allowed
   - Everyone else: hidden and blocked from access/edit/delete

## Fast Install (Windows)
From package folder, copy files into your live SillyTavern folder:

```powershell
$src = 'C:\Users\water\Desktop\SillyTavern-PushPatch-Package'
$dst = 'C:\Path\To\SillyTavern'
Copy-Item "$src\public\index.html" "$dst\public\index.html" -Force
Copy-Item "$src\public\style.css" "$dst\public\style.css" -Force
Copy-Item "$src\public\scripts\world-info.js" "$dst\public\scripts\world-info.js" -Force
Copy-Item "$src\src\endpoints\worldinfo.js" "$dst\src\endpoints\worldinfo.js" -Force
Copy-Item "$src\src\endpoints\characters.js" "$dst\src\endpoints\characters.js" -Force
```

Then:
1. Restart SillyTavern server
2. Hard refresh browser (`Ctrl+F5`)

## Minimal-Downtime Rollout Plan

### Phase A: Prepare in parallel (no downtime)
1. Make a staging copy of your SillyTavern folder.
2. Apply these files to staging.
3. Run syntax checks:

```powershell
node --check src/endpoints/worldinfo.js
node --check src/endpoints/characters.js
node --check public/scripts/world-info.js
```

4. Start staging instance and verify logs show normal startup.

### Phase B: Cutover (seconds of downtime)
1. Stop production SillyTavern process.
2. Copy validated files into production folder.
3. Start server immediately.
4. Hard refresh client.

## How to Use Another LLM Safely (GLM/Kimi/GPT/Sonnet/Opus)
Use this exact workflow so the model edits only intended files.

### Recommended prompt template
Provide this to the other LLM:

```text
You are patching a SillyTavern repo. Modify ONLY these files:
- public/index.html
- public/style.css
- public/scripts/world-info.js
- src/endpoints/worldinfo.js
- src/endpoints/characters.js

Requirements:
1) Add world popup push buttons (#world_popup_share, #world_bulk_push).
2) Add frontend handlers for single push and admin bulk push.
3) Add backend routes: /push, /bulk-push, /find-characters, /admin-handles, /push-notifications.
4) Preserve dd-* naming and original creator metadata when admin re-pushes user-pushed lorebooks.
5) Hidden pushed lorebooks must be accessible ONLY by admin or original creator.
6) Non-admin/non-creator must not get lorebook data, edit, or delete those hidden pushed books.
7) Keep CSS valid (@charset first).
8) Do not refactor unrelated code.

After edits, run:
- node --check src/endpoints/worldinfo.js
- node --check src/endpoints/characters.js
- node --check public/scripts/world-info.js

Return:
- exact changed files list
- any failed checks
- quick rollback command
```

### Guardrails for any LLM
1. Force file allowlist (only 5 files above).
2. Require syntax checks before completion.
3. Reject any large unrelated formatting/refactors.
4. Keep a rollback copy of original 5 files.

## Rollback (instant)
If anything fails:
1. Stop server.
2. Restore prior versions of the 5 files.
3. Restart server.

## Post-Install Smoke Test
1. Open World Info editor.
2. Confirm push buttons visible.
3. User pushes lorebook to admin.
4. Admin bulk pushes to users.
5. On non-admin/non-creator account:
   - lorebook should not appear in list
   - direct access/edit/delete should fail
6. On admin and creator accounts:
   - lorebook accessible and editable
