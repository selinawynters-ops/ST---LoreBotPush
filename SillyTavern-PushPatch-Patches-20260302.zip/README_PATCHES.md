﻿# Unified Patch Bundle

## Contents
- patches/00-all-changes.patch (all files)
- patches/01-public-index-html.patch
- patches/02-public-style-css.patch
- patches/03-public-scripts-world-info-js.patch
- patches/04-src-endpoints-characters-js.patch
- patches/05-src-endpoints-worldinfo-js.patch

## Apply from SillyTavern repo root
```powershell
git apply --reject "C:\Users\water\Desktop\SillyTavern-PushPatch-Patches\patches\00-all-changes.patch"
```

## Validate
```powershell
node --check src/endpoints/worldinfo.js
node --check src/endpoints/characters.js
node --check public/scripts/world-info.js
```

## Rollback
```powershell
git checkout -- public/index.html public/style.css public/scripts/world-info.js src/endpoints/characters.js src/endpoints/worldinfo.js
```
